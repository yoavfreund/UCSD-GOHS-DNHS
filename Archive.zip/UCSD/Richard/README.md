UCSD-GOHS-DNHS
==============

A repository for a summer project on data analysis. Led by Yoav Freund UCSD.

An interesting way to publish a notebook to the world is by using a git Gist and 
the nbviewer service, such as so: http://nbviewer.ipython.org/5856469
