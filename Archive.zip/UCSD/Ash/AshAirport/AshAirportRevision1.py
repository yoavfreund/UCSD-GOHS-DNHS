def choice():
    x = str(raw_input(" 'Yes' or 'No': "))
    if x == 'Yes':
        print("Have an nice flight!")   
    elif x == 'No':
        print("Have a nice day!")   
    else:
        print("Invalid Selection")
weight = float(raw_input("How many pounds does your suitcase weigh? "))
if weight > 50:
    print("There is a $25 charge for luggage that heavy, would you like to pay the fee?.")
    choice()
elif weight <= 50:
    print("You are good to go! Will you be boarding?")
    choice()
