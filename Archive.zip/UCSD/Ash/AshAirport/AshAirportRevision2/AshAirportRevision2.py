file = open('./warnings.txt', 'r')
def choice():
    invalid = True
    while invalid == True:
        x = str(raw_input("'Yes' or 'No': "))
        if x == 'Yes' or x == 'yes' or x == 'y':
            print("Have an nice flight!")
            invalid = False
        elif x == 'No' or x == 'no' or x == 'n':
            print("Have a nice day!")
            invalid = False
        else:
            print("Invalid Selection")
            invalid = True
def lineSel(first, last):
    y = 0
    for lines in file.readlines():
            if y >= first and y <= last:
                print lines
            y +=1
weight = float(raw_input("How many pounds does your suitcase weigh? "))
if weight > 50:
    print("There is a $25 charge for luggage that heavy, would you like to pay the fee?.")
    choice()
elif weight <= 50:
    print("You are good to go! Will you be boarding?")
    choice()

invalid2 = True
while invalid2 == True:
    region = str(raw_input('''Which region encompasses your destination?:
Africa
Asia
European Union
Middle East
-->'''))
    if region == "Africa":
        lineSel(2, 38)
        invalid2 = False
    elif region == "Asia":
        lineSel(40, 47)
        invalid2 = False
    elif region == "European Union":
        lineSel(49, 50)
        invalid2 = False
    elif region == "Middle East":
        lineSel(52, 86)
        invalid2 = False
    else:
        print "Invalid selection"
        invalid2 = True
